# hw4_Basic-Algorithms-in-Artificial-Intelligenc

`task1.py`、`task2.py`分别为K均值聚类算法、分级聚类算法；

`task2_evaluate.py`利用`task2.py`计算生成的结果计算、绘制轮廓函数值关于层数的曲线图；

`task2_standard.py`直接利用`scipy`库进行分级聚类计算并计算轮廓函数，对`task2.py`进行验证；

`task2_gen_best.py`生成分级聚类计算最终聚类结果的每个簇的平均图像。
